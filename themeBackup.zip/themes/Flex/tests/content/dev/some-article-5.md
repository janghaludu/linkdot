Title: Some Article 5
Date: 2016-03-01 12:00
Modified: 2016-03-01 12:00
Tags: article, pelican, python
Slug: some-article-5

This is an article with category dev.