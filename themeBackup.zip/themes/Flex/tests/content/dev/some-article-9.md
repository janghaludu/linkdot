Title: Some Article 9
Date: 2016-01-01 08:00
Modified: 2016-01-01 08:00
Tags: article, pelican, python
Slug: some-article-9

This is an article with category dev.